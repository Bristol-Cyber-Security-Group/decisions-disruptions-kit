# Decisions & Disruptions, the debrief tool

Copyright Sylvain Frey, University of Southampton, CC-BY-NC.               

Contact: s.a.f.frey [at] soton.ac.uk        http://twitter.com/sylfrey

This code is published under the Creative Commons licence.

To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/ .

[Decisions & Disruptions](http://decisions-disruptions.org) is a tabletop cyber security game, also licenced CC-BY-NC by Lancaster University.
